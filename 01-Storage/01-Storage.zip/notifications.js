module.exports = {
    invalidKeyTypeMsg: "Invalid type: key should be a string",
    keyAlreadyExistsMsg: "Key already exists",
    keyDoesNotExistMsg: "Key does not exist",
    storageIsEmptyMsg: "No items in the storage",
    storageClearedMsg: "Currently storage is cleared",
    fileSavedMsg: "File saved",
    fileLoadedMsg: "File loaded"
};