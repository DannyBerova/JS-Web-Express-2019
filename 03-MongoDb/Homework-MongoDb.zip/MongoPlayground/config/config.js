module.exports = {
    development: {
        connectionString: "mongodb://localhost:27017/mongo-db-playground"
    },
    production: {
        connectionString: null
    }
};