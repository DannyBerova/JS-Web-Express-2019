module.exports = {
    registerGet: (req, res) => {
        // TODO:
    },
    registerPost: async (req, res) => {
       // TODO:
    },
    logout: (req, res) => {
        // TODO:
    },
    loginGet: (req, res) => {
        // TODO:
    },
    loginPost: async (req, res) => {
        // TODO:
    }
};