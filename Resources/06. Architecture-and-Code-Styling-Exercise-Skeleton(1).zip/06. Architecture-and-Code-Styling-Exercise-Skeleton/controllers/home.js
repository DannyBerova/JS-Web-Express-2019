module.exports = {
  index: (req, res) => {
    // TODO load all (if any) articles and pass them as context
    res.render('home/index');
  }
}
